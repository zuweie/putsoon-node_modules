# Installation
> `npm install --save @types/cookies`

# Summary
This package contains type definitions for cookies (https://github.com/pillarjs/cookies).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/cookies

Additional Details
 * Last updated: Wed, 02 Oct 2019 21:55:45 GMT
 * Dependencies: @types/keygrip, @types/express, @types/connect, @types/node
 * Global values: none

# Credits
These definitions were written by Wang Zishi <https://github.com/WangZishi>, jKey Lu <https://github.com/jkeylu>, and BendingBender <https://github.com/BendingBender>.
