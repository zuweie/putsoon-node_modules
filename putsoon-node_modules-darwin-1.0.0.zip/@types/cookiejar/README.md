# Installation
> `npm install --save @types/cookiejar`

# Summary
This package contains type definitions for CookieJar (https://github.com/bmeck/node-cookiejar).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/cookiejar

Additional Details
 * Last updated: Wed, 16 Jan 2019 19:36:53 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Rafal Proszowski <https://github.com/paroxp>.
