# Installation
> `npm install --save @types/supertest`

# Summary
This package contains type definitions for SuperTest (https://github.com/visionmedia/supertest).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/supertest

Additional Details
 * Last updated: Wed, 03 Jul 2019 16:47:17 GMT
 * Dependencies: @types/superagent
 * Global values: none

# Credits
These definitions were written by Alex Varju <https://github.com/varju>, and Petteri Parkkila <https://github.com/pietu>.
