# Installation
> `npm install --save @types/koa-compose`

# Summary
This package contains type definitions for koa-compose (https://github.com/koajs/compose).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/koa-compose

Additional Details
 * Last updated: Thu, 07 Nov 2019 17:55:21 GMT
 * Dependencies: @types/koa
 * Global values: none

# Credits
These definitions were written by jKey Lu <https://github.com/jkeylu>, and Anton Astashov <https://github.com/astashov>.
