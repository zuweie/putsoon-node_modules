# Installation
> `npm install --save @types/dargs`

# Summary
This package contains type definitions for dargs (https://github.com/sindresorhus/dargs#readme).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/dargs

Additional Details
 * Last updated: Mon, 14 Aug 2017 18:44:00 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by BendingBender <https://github.com/BendingBender>.
