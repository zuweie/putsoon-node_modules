# Installation
> `npm install --save @types/eslint-visitor-keys`

# Summary
This package contains type definitions for eslint-visitor-keys (https://github.com/eslint/eslint-visitor-keys#readme).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/eslint-visitor-keys

Additional Details
 * Last updated: Sun, 18 Feb 2018 01:53:11 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Toru Nagashima <https://github.com/mysticatea>.
