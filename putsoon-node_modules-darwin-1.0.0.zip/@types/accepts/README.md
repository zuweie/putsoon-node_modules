# Installation
> `npm install --save @types/accepts`

# Summary
This package contains type definitions for accepts (https://github.com/jshttp/accepts).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/accepts

Additional Details
 * Last updated: Tue, 13 Feb 2018 02:54:18 GMT
 * Dependencies: http, node
 * Global values: none

# Credits
These definitions were written by Stefan Reichel <https://github.com/bomret>, Brice BERNARD <https://github.com/brikou>.
