declare var implementation: string;

export = implementation;
