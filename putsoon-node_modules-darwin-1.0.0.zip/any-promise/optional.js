"use strict";
try {
  module.exports = require('./register')().Promise || null
} catch(e) {
  module.exports = null
}
